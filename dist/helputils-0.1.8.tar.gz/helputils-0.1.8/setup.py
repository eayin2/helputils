from distutils.core import setup
from setuptools import find_packages

setup(
    name="helputils",
    version="0.1.8",
    author="eayin2",
    author_email="eayin2 at gmail dot com",
    packages=find_packages(),
    description="Bunch of random functions and classes that are useful.",
    install_requires=[],
)
#    url="https://github.com/eayin2/",

